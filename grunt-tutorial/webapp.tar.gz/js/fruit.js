var fruit = 'apples';
console.log(fruit);